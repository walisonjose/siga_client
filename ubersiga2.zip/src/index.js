import React from "react";
import Map from "./components/Map";
import Login from "./components/signIn";

const App = () => <Login />;

export default App;
